import Image from "next/image"

const clients = [
  { name: "TechCorp", logo: "/techcorp-logo.png" },
  { name: "GreenEnergy", logo: "/greenenergy-logo.png" },
  { name: "HealthPlus", logo: "/healthplus-logo.png" },
  { name: "EduLearn", logo: "/edulearn-logo.png" },
  { name: "FinanceHub", logo: "/financehub-logo.png" },
  { name: "TravelJoy", logo: "/traveljoy-logo.png" },
]

export function Clients() {
  return (
    <section id="clients" className="py-20">
      <div className="container">
        <h2 className="text-3xl font-bold mb-8 text-center">Clients I've Worked With</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
          {clients.map((client, index) => (
            <div key={index} className="flex flex-col items-center justify-center">
              <Image
                src={client.logo}
                alt={client.name}
                width={150}
                height={75}
                className="object-contain"
              />
              <span className="mt-2 text-sm text-muted-foreground">{client.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

