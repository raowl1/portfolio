"use client"

import { useState } from "react"
import Image from "next/image"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import * as Icons from 'lucide-react'

const portfolioItems = [
  {
    title: "The Future of AI in Content Creation",
    image: "/placeholder.svg?height=200&width=300",
    link: "https://example.com/article1"
  },
  {
    title: "10 Tips for Effective SEO Writing",
    image: "/placeholder.svg?height=200&width=300",
    link: "https://example.com/article2"
  },
  {
    title: "How to Create Engaging Social Media Content",
    image: "/placeholder.svg?height=200&width=300",
    link: "https://example.com/article3"
  },
  {
    title: "The Art of Storytelling in Marketing",
    image: "/placeholder.svg?height=200&width=300",
    link: "https://example.com/article4"
  },
  {
    title: "Mastering the Craft of Technical Writing",
    image: "/placeholder.svg?height=200&width=300",
    link: "https://example.com/article5"
  },
  {
    title: "Content Strategy for Startups",
    image: "/placeholder.svg?height=200&width=300",
    link: "https://example.com/article6"
  },
  {
    title: "The Power of Persuasive Copywriting",
    image: "/placeholder.svg?height=200&width=300",
    link: "https://example.com/article7"
  },
  {
    title: "Writing for Voice Search Optimization",
    image: "/placeholder.svg?height=200&width=300",
    link: "https://example.com/article8"
  },
  {
    title: "Creating Compelling Email Newsletters",
    image: "/placeholder.svg?height=200&width=300",
    link: "https://example.com/article9"
  },
  {
    title: "The Role of Content in Customer Experience",
    image: "/placeholder.svg?height=200&width=300",
    link: "https://example.com/article10"
  },
]

export function Portfolio() {
  const [currentPage, setCurrentPage] = useState(0)
  const itemsPerPage = 4
  const totalPages = Math.ceil(portfolioItems.length / itemsPerPage)

  const nextPage = () => {
    setCurrentPage((prev) => (prev + 1) % totalPages)
  }

  const prevPage = () => {
    setCurrentPage((prev) => (prev - 1 + totalPages) % totalPages)
  }

  const currentItems = portfolioItems.slice(
    currentPage * itemsPerPage,
    (currentPage + 1) * itemsPerPage
  )

  return (
    <section id="portfolio" className="py-20">
      <div className="container">
        <h2 className="text-3xl font-bold mb-8 text-center">My Portfolio</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {currentItems.map((item, index) => (
            <Card key={index}>
              <CardContent className="p-0">
                <Image
                  src={item.image}
                  alt={item.title}
                  width={300}
                  height={200}
                  className="w-full h-auto"
                />
              </CardContent>
              <CardFooter className="flex flex-col items-start">
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <Button asChild variant="link" className="p-0">
                  <a href={item.link} target="_blank" rel="noopener noreferrer">Read Article</a>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        <div className="flex justify-center mt-8 space-x-4">
          <Button onClick={prevPage} variant="outline" size="icon">
            <Icons.ChevronLeft className="h-4 w-4" />
          </Button>
          <Button onClick={nextPage} variant="outline" size="icon">
            <Icons.ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}

