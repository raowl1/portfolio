import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const testimonials = [
  {
    name: "John Smith",
    company: "TechCorp",
    avatar: "/placeholder.svg?height=40&width=40",
    testimonial: "Jane's content has significantly improved our online presence and engagement rates."
  },
  {
    name: "Sarah Johnson",
    company: "GreenEnergy",
    avatar: "/placeholder.svg?height=40&width=40",
    testimonial: "Working with Jane was a pleasure. Her writing perfectly captured our brand voice."
  },
  {
    name: "Michael Brown",
    company: "HealthPlus",
    avatar: "/placeholder.svg?height=40&width=40",
    testimonial: "Jane's SEO-optimized articles have boosted our organic traffic by 200%."
  },
]

export function Testimonials() {
  return (
    <section className="py-20 bg-muted">
      <div className="container">
        <h2 className="text-3xl font-bold mb-8 text-center">What Clients Say</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index}>
              <CardContent className="pt-6">
                <p className="text-muted-foreground italic">"{testimonial.testimonial}"</p>
              </CardContent>
              <CardFooter className="flex items-center space-x-4">
                <Avatar>
                  <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                  <AvatarFallback>{testimonial.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.company}</p>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

