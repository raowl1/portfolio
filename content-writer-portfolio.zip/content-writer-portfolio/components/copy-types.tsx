import { Badge } from "@/components/ui/badge"

const copyTypes = [
  "Blog Posts",
  "SEO Articles",
  "White Papers",
  "Case Studies",
  "Email Newsletters",
  "Social Media Content",
  "Product Descriptions",
  "Technical Writing",
  "Press Releases",
  "eBooks",
]

export function CopyTypes() {
  return (
    <section className="py-20 bg-gradient-to-b from-background to-muted">
      <div className="container flex flex-col items-center">
        <h2 className="text-4xl font-extrabold mb-4 text-center text-primary">
          Versatile Copywriting Expertise
        </h2>
        <p className="text-xl text-center mb-8 text-muted-foreground">
          Crafting compelling content across various formats to meet your unique needs
        </p>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 justify-items-center">
          {copyTypes.map((type, index) => (
            <Badge key={index} variant="secondary" className="text-lg py-2 px-4 flex items-center justify-center h-full">
              {type}
            </Badge>
          ))}
        </div>
      </div>
    </section>
  )
}

