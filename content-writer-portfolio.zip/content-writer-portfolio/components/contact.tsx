import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import * as Icons from 'lucide-react'
import Image from "next/image"

export function Contact() {
  return (
    <section id="contact" className="py-20 bg-primary text-primary-foreground">
      <div className="container max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-12 text-center">Get in Touch</h2>
        <div className="grid md:grid-cols-3 gap-12 md:gap-20 items-start">
          <div className="space-y-6 px-4">
            <Image src="/logo.png" alt="Logo" width={100} height={100} className="mx-auto" />
            <p className="text-sm text-center">
              I'm a professional content writer with over 10 years of experience crafting compelling stories and engaging copy for various industries.
            </p>
          </div>
          <form className="space-y-6 px-4">
            <Input type="text" placeholder="Your Name" required className="bg-primary-foreground text-primary" />
            <Input type="email" placeholder="Your Email" required className="bg-primary-foreground text-primary" />
            <Textarea placeholder="Your Message" required className="bg-primary-foreground text-primary" />
            <Button type="submit" className="w-full" variant="secondary">Send Message</Button>
          </form>
          <div className="space-y-6 px-4">
            <h3 className="text-xl font-semibold mb-4">Connect with Me</h3>
            <div className="flex items-center space-x-2">
              <Icons.Phone className="h-5 w-5" />
              <span>+1 (555) 123-4567</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icons.Instagram className="h-5 w-5" />
              <span>Instagram</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icons.MessageCircle className="h-5 w-5" />
              <span>WhatsApp</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icons.Linkedin className="h-5 w-5" />
              <span>LinkedIn</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

